"""HSI filtering practical: six spatial filters on the intensity channel."""
from pathlib import Path
import numpy as np
from PIL import Image, ImageOps, ImageDraw
ROOT=Path(__file__).resolve().parent
INPUT=ROOT/'input'/'input.jpg'; OUTPUT=ROOT/'output'; OUTPUT.mkdir(exist_ok=True)

def rgb_to_hsi(im):
 a=np.asarray(im.convert('RGB'),dtype=np.float32)/255.; r,g,b=a[...,0],a[...,1],a[...,2]
 I=(r+g+b)/3.; mn=np.minimum(np.minimum(r,g),b); S=np.zeros_like(I); nz=I>1e-8; S[nz]=1-mn[nz]/I[nz]
 num=.5*((r-g)+(r-b)); den=np.sqrt((r-g)**2+(r-b)*(g-b)); q=np.zeros_like(I); v=den>1e-8; q[v]=np.clip(num[v]/den[v],-1,1)
 th=np.arccos(q); H=np.where(b<=g,th,2*np.pi-th); H[S<=1e-8]=0
 return H,S,I

def hsi_to_rgb(H,S,I):
 H=np.mod(H,2*np.pi); S=np.clip(S,0,1); I=np.clip(I,0,1); r=np.zeros_like(I);g=np.zeros_like(I);b=np.zeros_like(I)
 m=H<2*np.pi/3; x=H[m]; b[m]=I[m]*(1-S[m]); r[m]=I[m]*(1+S[m]*np.cos(x)/np.maximum(np.cos(np.pi/3-x),1e-8)); g[m]=3*I[m]-r[m]-b[m]
 m=(H>=2*np.pi/3)&(H<4*np.pi/3); x=H[m]-2*np.pi/3; r[m]=I[m]*(1-S[m]); g[m]=I[m]*(1+S[m]*np.cos(x)/np.maximum(np.cos(np.pi/3-x),1e-8)); b[m]=3*I[m]-r[m]-g[m]
 m=H>=4*np.pi/3; x=H[m]-4*np.pi/3; g[m]=I[m]*(1-S[m]); b[m]=I[m]*(1+S[m]*np.cos(x)/np.maximum(np.cos(np.pi/3-x),1e-8)); r[m]=3*I[m]-g[m]-b[m]
 return Image.fromarray(np.uint8(np.clip(np.stack((r,g,b),-1)*255,0,255)))

def filter2d(a,name):
 p=np.pad(a,1,mode='edge'); h,w=a.shape; z=[p[y:y+h,x:x+w] for y in range(3) for x in range(3)]
 if name=='averaging': out=np.mean(z,axis=0)
 elif name=='median': out=np.median(z,axis=0)
 elif name=='maximum': out=np.max(z,axis=0)
 elif name=='minimum': out=np.min(z,axis=0)
 else:
  k=np.array([[1,2,1],[2,4,2],[1,2,1]],float)/16
  out=sum(k[y,x]*z[3*y+x] for y in range(3) for x in range(3))
 return np.clip(out,0,1)

def main():
 if not INPUT.exists(): raise FileNotFoundError(INPUT)
 im=Image.open(INPUT).convert('RGB'); im.save(OUTPUT/'original.png'); H,S,I=rgb_to_hsi(im)
 names=['averaging','gaussian','maximum','median','minimum','weighted_average']; thumbs=[]
 for name in names:
  out=hsi_to_rgb(H,S,filter2d(I,name)); out.save(OUTPUT/f'{name}.png'); thumbs.append((name,out.copy()))
 # labeled 2-column comparison sheet
 tw,th=306,235; sheet=Image.new('RGB',(tw*2,th*4),(245,245,245)); d=ImageDraw.Draw(sheet)
 for idx,(name,pic) in enumerate([('original',im)]+thumbs):
  x=(idx%2)*tw; y=(idx//2)*th; pic.thumbnail((tw-16,th-38)); sheet.paste(pic,(x+8,y+26)); d.text((x+8,y+7),name.replace('_',' ').title(),fill=(20,20,20))
 sheet.save(OUTPUT/'all_filters_comparison.png')
 print('Generated six filter outputs and comparison sheet.')
if __name__=='__main__': main()
